---
title: Ejemplo técnico
---
Ejemplo de reglas: resultados seguros.
