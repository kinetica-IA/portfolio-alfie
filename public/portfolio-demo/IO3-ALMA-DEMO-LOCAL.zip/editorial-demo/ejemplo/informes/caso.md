---
title: Ejemplo artificial
---
No prometemos «resultados seguros».
