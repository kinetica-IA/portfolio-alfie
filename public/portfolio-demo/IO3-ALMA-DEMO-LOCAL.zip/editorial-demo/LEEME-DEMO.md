# Ejecutar este paquete

Desde esta carpeta, con Python 3.13 (solo biblioteca estándar):

```sh
python3 -m unittest discover -s . -v
python3 revisar_contenido.py --content-root ejemplo
```

Las doce pruebas deben pasar. El ejemplo contiene un texto artificial sin referencia y una expresión negada: el CLI devuelve código 1 y REQUIERE_REVISION_HUMANA; eso es el comportamiento esperado, no una aprobación o un fallo de ejecución. Una ruta ausente devuelve código 2. No requiere red, credenciales, modelos ni datos personales. No usar el ejemplo como una recomendación sanitaria.

README.md preserva la documentación del proyecto de origen. Aquí los comandos son los indicados arriba; en la web principal la fuente operativa está en scripts/editorial/.
