from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import train_retrospective as train
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
root=args.output
if root.exists():raise SystemExit('La salida ya existe; elige otra ruta para no sobrescribir datos.')
root.mkdir(parents=True)
index=pd.date_range('2020-01-01',periods=42)
daily=pd.DataFrame({f:10+np.sin(np.arange(42)*(i+1)) for i,f in enumerate(train.FEATURES)},index=index)
diary=pd.DataFrame({column:np.where(np.arange(42)%2,7,3) for column,_ in train.TARGETS.values()},index=index)
daily.to_csv(root/'synthetic-daily.csv',index_label='date');diary.to_csv(root/'synthetic-diary.csv',index_label='date')
report=train.run(root/'synthetic-daily.csv',root/'synthetic-diary.csv',root/'results','2026-11-16')
print('DEMO SINTÉTICA: no usar sus métricas como resultado del estudio personal.')
print('Objetivos:',len(report['results']));print(root/'results/public-summary.json')
