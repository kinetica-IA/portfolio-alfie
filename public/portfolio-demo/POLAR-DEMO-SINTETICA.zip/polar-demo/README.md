# Polar: demostración sintética reproducible

Python 3.13. Instalar `requirements.txt` en un entorno separado. Después:

```sh
python test_train_retrospective.py
python demo.py --output /ruta/nueva/demo-sintetica
```

Genera 42 fechas artificiales, cinco objetivos y el informe. Las métricas de esta demo NO son resultados del estudio personal ni validación clínica. No incluye diario, notas, pesos personales o exportaciones Polar. No publica ni descarga datos. La carpeta elegida debe ser nueva. El análisis personal publicado conserva sus propios límites y trazabilidad pendiente.
